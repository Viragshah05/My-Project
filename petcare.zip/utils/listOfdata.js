export const carePagedetail = [
  {
    details:
      "Well, have a look at the videos we have shot. Our experts team takes care of the pets in a professional yet friendly way. They are all been provided with specialized training and are been watched by our CCTV.",
    subtitle: " Worried about how we will treat them while you are away? 1 ",
  },
  {
    details:
      "Well, have a look at the videos we have shot. Our experts team takes care of the pets in a professional yet friendly way. They are all been provided with specialized training and are been watched by our CCTV.",
    subtitle: " Worried about how we will treat them while you are away?2  ",
  },
  {
    details:
      "Well, have a look at the videos we have shot. Our experts team takes care of the pets in a professional yet friendly way. They are all been provided with specialized training and are been watched by our CCTV.",
    subtitle: " Worried about how we will treat them while you are away? 3 ",
  },
  {
    details:
      "Well, have a look at the videos we have shot. Our experts team takes care of the pets in a professional yet friendly way. They are all been provided with specialized training and are been watched by our CCTV.",
    subtitle: " Worried about how we will treat them while you are away? 4 ",
  },
  {
    details:
      "Well, have a look at the videos we have shot. Our experts team takes care of the pets in a professional yet friendly way. They are all been provided with specialized training and are been watched by our CCTV.",
    subtitle: " Worried about how we will treat them while you are away?5  ",
  },
];

export const companyDetails = [
  {
    image: "/Images/ribbine.svg",
    title: "85+",
    describe: " Award",
  },
  {
    image: "/Images/people.svg",
    title: "90+",
    describe: "  Clients",
  },
  {
    image: "/Images/dogplay.svg",
    title: "60+",
    describe: "Employee",
  },
  {
    image: "/Images/security.svg",
    title: "99%",
    describe: "Protection",
  },
];

export const clientFeedback = [
  {
    feedback:
      "1 ) We have got our first pet 2 years back and we wanted to train him. So, one of our family friend gave us the reference of this location and brought our dog for training it took our dog 3 months to get trained & we are happy with their  service.",
  },
  {
    feedback:
      "2 ) We have got our first pet 2 years back and we wanted to train him. So, one of our family friend gave us the reference of this location and brought our dog for training it took our dog 3 months to get trained & we are happy with their  service.",
  },
  {
    feedback:
      "3 ) We have got our first pet 2 years back and we wanted to train him. So, one of our family friend gave us the reference of this location and brought our dog for training it took our dog 3 months to get trained & we are happy with their  service.",
  },
  {
    feedback:
      "4 ) We have got our first pet 2 years back and we wanted to train him. So, one of our family friend gave us the reference of this location and brought our dog for training it took our dog 3 months to get trained & we are happy with their  service.",
  },
  {
    feedback:
      "5 ) We have got our first pet 2 years back and we wanted to train him. So, one of our family friend gave us the reference of this location and brought our dog for training it took our dog 3 months to get trained & we are happy with their  service.",
  },
];
